extends Control
@onready var score_final = $Label2

func _ready() -> void:
	score_final.text = "Score Final: " + str(Global.score_final)
